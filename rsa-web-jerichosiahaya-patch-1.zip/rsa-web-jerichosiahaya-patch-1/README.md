Repo for reminder service application project.
